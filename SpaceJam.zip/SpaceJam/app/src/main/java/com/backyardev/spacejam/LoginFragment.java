package com.backyardev.spacejam;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;


public class LoginFragment extends Fragment implements View.OnClickListener {


    Button btnLogin;
    ProgressBar progressBar,regProgress;
    public TextView forgotPass,instead;
    public String mailLogin,passLogin;
    TextInputEditText eMailText, userMailText,userPassText;
    public FirebaseAuth mAuth;
    public ViewPager viewPager;


    public LoginFragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.login_fragment,
                container, false);
        mAuth = FirebaseAuth.getInstance();


        userPassText=view.findViewById( R.id.userPassText );
        userMailText =view.findViewById( R.id.userMailText );
        progressBar=view.findViewById( R.id.progressBar );
        regProgress=view.findViewById( R.id.regProgress );
        btnLogin = view.findViewById(R.id.btnLogin);
        instead=view.findViewById( R.id.createAccText );
        forgotPass=view.findViewById( R.id.forgotText );
        viewPager=view.findViewById( R.id.viewPager );

        btnLogin.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
               login();
            }
        });

        forgotPass.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View arg1) {
                forgotPassword();
            }
        } );

        instead.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View arg2) {
               viewPager.setCurrentItem( 1,true );
            }
        } );

        return view;
    }


    public void login() {mailLogin = userMailText.getText().toString();
        passLogin= userPassText.getText().toString();
        boolean submit=true;

        if(mailLogin.isEmpty()){
            userMailText.setError("Required Field!");
            submit=false;
        }if(passLogin.isEmpty()){
            userPassText.setError("Required Field!");
            submit=false;
        }
        if(submit){
          submitLogin();
        }
    }


    public void submitLogin(){
        progressBar.setVisibility( View.VISIBLE );
        btnLogin.setVisibility( View.INVISIBLE );
        btnLogin.setEnabled( false );
        mAuth.signInWithEmailAndPassword(mailLogin,passLogin ).addOnCompleteListener( new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (!task.isSuccessful()) {
                    progressBar.setVisibility( View.INVISIBLE );
                    btnLogin.setEnabled( true );
                    btnLogin.setVisibility( View.VISIBLE );
                    try {
                        Log.d( "loginTest", String.valueOf( task.getException() ) );
                        throw task.getException();

                    } catch (FirebaseAuthInvalidUserException e) {
                        Log.d( "login test", "onComplete: invalid email" );
                        Toast.makeText(getContext(), "Account not registered yet!", Toast.LENGTH_SHORT).show();
                        instead.setVisibility(View.VISIBLE );
                    } catch (FirebaseAuthInvalidCredentialsException wrongPassword) {
                        Log.d( "loginTest", "onComplete: wrong_password" );
                        forgotPass.setVisibility( View.VISIBLE );
                        userPassText.setError( "Invalid password" );
                        userPassText.requestFocus();
                    } catch (Exception e) {
                        Log.d( "loginTest extra", e.getMessage() );
                    }
                }
                else
                {
                    Log.d("loginTest", "signInWithEmail:success");
                    Intent i = new Intent( getActivity(),HomeActivity.class );
                    startActivity( i );
                }
            }
        } );
    }


    public void forgotPassword(){
        progressBar.setVisibility( View.VISIBLE );
        FirebaseAuth auth = FirebaseAuth.getInstance();
        String emailAddress = userMailText.getText().toString();
        Log.d( "mail",emailAddress );
        auth.sendPasswordResetEmail( emailAddress ).addOnCompleteListener( new OnCompleteListener <Void>() {
            @Override
            public void onComplete(@NonNull Task <Void> task) {
                progressBar.setVisibility( View.INVISIBLE );
                if (task.isSuccessful()) {
                    Log.d("reset mail", "Email sent.");
                    Toast.makeText( getContext(),"A password reset email has been sent! Check your inbox",Toast.LENGTH_LONG ).show();
                }else{
                    try {
                        throw task.getException();
                    } catch (Exception e) {
                        Toast.makeText( getContext(), e.getMessage(),Toast.LENGTH_SHORT ).show();
                    }
                }
            }
        } );

    }

    @Override
    public void onClick(View view) {

    }
}
