package com.backyardev.spacejam;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class RegisterFragment extends Fragment {
    private String nameReg,passReg,mailReg;
    private FirebaseAuth mAuth;
    private TextInputEditText nameText, passText, eMailText;
    Button btnRegister;
    ProgressBar regProgress;
    private static final String TAG = "LoginActivityTags";
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    public RegisterFragment() {
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.login_fragment,
                container, false);
        btnRegister=view.findViewById( R.id.btnRegister );


        regProgress=view.findViewById( R.id.regProgress );
        nameText=view.findViewById( R.id.NameText );
        passText=view.findViewById( R.id.PassText );
        eMailText=view.findViewById( R.id.eMailText );
        mAuth = FirebaseAuth.getInstance();
        btnRegister.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nameReg= nameText.getText().toString();
                passReg= passText.getText().toString().trim();
                mailReg= eMailText.getText().toString();

                boolean submit=true;

                if(nameReg.isEmpty()){

                    nameText.setError("Required Field!");
                    submit=false;

                }if (!isValidPassword(passReg) && passReg.length()<9) {

                    Toast.makeText(getContext(), "Invalid password", Toast.LENGTH_SHORT).show();
                    passText.setError( "Minimum 8 letters, a symbol, a number, an Uppercase letter and a lower case letter!" );
                    submit=false;

                }if(isValidEmail( mailReg )){

                    eMailText.setError("Invalid eMail Id!");
                    submit=false;

                }if(submit){
                    register();
                }
            }
        } );

        return view;
    }
    private void register() {
        regProgress.setVisibility( View.VISIBLE );
        btnRegister.setVisibility( View.INVISIBLE );
        btnRegister.setEnabled( false );
        Map<String, Object> user =new HashMap<>(  );
        user.put("name", nameReg );
        user.put("email", mailReg );
        user.put("password", passReg );

        db.collection("users")
                .add(user)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        regProgress.setVisibility( View.INVISIBLE );
                        btnRegister.setEnabled( true );
                        btnRegister.setVisibility( View.VISIBLE );
                        Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                        Toast.makeText(getContext(), "Registration Successful!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error adding document", e);
                        Toast.makeText(getContext(), "Registration Failed!", Toast.LENGTH_SHORT).show();

                    }
                });
    }

    public boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;

        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{4,}$";

        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();

    }
    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

}
